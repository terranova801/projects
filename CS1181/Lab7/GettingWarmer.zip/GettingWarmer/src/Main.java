import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        JFrame gui = new JFrame("tempConverter");
        gui.setSize(700, 500);
        gui.setLocation(100, 100);
        gui.setVisible(true);
        gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton button = new JButton("Push to Convert");
        JLabel label = new JLabel("Convert");

        JPanel panel = new JPanel();
        panel.add(button);
        panel.add(label);
        gui.add(panel);
    }
}
