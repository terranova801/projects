## Citations
- [GeeksforGeeks - Queue Interfaces](https://www.geeksforgeeks.org/java/queue-interface-java/)
- [Digital Ocean - Java Queue](https://www.digitalocean.com/community/tutorials/java-queue)
- [Medium - Understanding Atomic Integer in Java](https://medium.com/@reetesh043/understanding-atomic-integer-in-java-c0f2aafe6837)