#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TASKS 100
#define MAX_NAME_LENGTH 50

void displayMenu();
void addTask();
void markTaskAsCompleted();
void removeTask();
void viewTodoList();